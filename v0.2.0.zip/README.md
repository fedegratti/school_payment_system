## Motivation

Somos el grupo 2 porque buscamos el camino a la excelencia sin dejar de lado la humildad.